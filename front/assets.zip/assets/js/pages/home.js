export async function HomePage(app) {
  app.innerHTML = `
    <h1>Bienvenido a Papelitos 🎮</h1>
    <p>Selecciona una opción del menú.</p>
  `;
}
