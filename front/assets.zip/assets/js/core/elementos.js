
import { BtnModal } from "../components/btnModal.js";
export const define = ()=>{
    customElements.define('btn-modal', BtnModal);  
} 